// For each product card, handle button click and size selection
document.querySelectorAll(".product").forEach(product => {
  const button = product.querySelector("button");
  const sizeSelect = product.querySelector(".size-select");

  button.addEventListener("click", () => {
    const size = sizeSelect ? sizeSelect.value : "N/A";
    const productName = product.querySelector("h3").innerText;
    alert(`Thanks for buying the ${productName} (Size: ${size})! ❤️ All funds go to the Children's Hospital.`);
  });
});
